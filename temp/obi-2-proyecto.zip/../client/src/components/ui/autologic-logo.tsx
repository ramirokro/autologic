import React from 'react';

interface AutologicLogoProps {
  className?: string;
}

const AutologicLogo: React.FC<AutologicLogoProps> = ({ className = "w-40 h-auto" }) => {
  return (
    <svg 
      viewBox="0 0 320 80" 
      className={className} 
      xmlns="http://www.w3.org/2000/svg"
    >
      {/* Barras del logo */}
      <rect x="10" y="10" width="20" height="60" rx="2" fill="#2D9CDB" />
      <rect x="40" y="10" width="20" height="60" rx="2" fill="#4F4F4F" />
      <rect x="70" y="10" width="20" height="60" rx="2" fill="#00CC88" />
      
      {/* Texto "autologic" */}
      <text
        x="110"
        y="55"
        fontSize="40"
        fontWeight="bold"
        fill="currentColor"
        fontFamily="sans-serif"
      >
        autologic
      </text>
    </svg>
  );
};

export default AutologicLogo;