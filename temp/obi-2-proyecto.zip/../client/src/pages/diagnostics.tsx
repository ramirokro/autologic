import React, { useState, useEffect, useRef } from 'react';
import { useLocation } from 'wouter';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { apiRequest } from '@/lib/queryClient';
import { 
  ChevronLeft, 
  Send, 
  CornerDownLeft, 
  Zap,
  AlertCircle,
  CheckCircle,
  AlertTriangle,
  Terminal,
  Settings,
  Wrench
} from 'lucide-react';

interface ChatMessage {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  severity?: 'none' | 'low' | 'medium' | 'high';
}

const DiagnosticsPage: React.FC = () => {
  const [, setLocation] = useLocation();
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [isThinking, setIsThinking] = useState(false);
  const [inputMessage, setInputMessage] = useState('');
  const [vehicleInfo, setVehicleInfo] = useState<{
    year?: number;
    make?: string;
    model?: string;
    engine?: string;
  }>({});
  const [obdCodes, setObdCodes] = useState<string[]>([]);
  const [symptoms, setSymptoms] = useState<string[]>([]);
  const [severity, setSeverity] = useState<string | null>(null);
  const [recommendedParts, setRecommendedParts] = useState<string[]>([]);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  // Auto scroll to bottom of chat
  useEffect(() => {
    if (messagesEndRef.current) {
      messagesEndRef.current.scrollIntoView({ behavior: 'smooth' });
    }
  }, [messages]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (inputMessage.trim()) {
      handleSendMessage(inputMessage);
      setInputMessage('');
    }
  };

  // Función para determinar la severidad basada en el texto del diagnóstico
  const determineSeverity = (diagnosis: string, severityStr?: string): 'none' | 'low' | 'medium' | 'high' => {
    // Si hay una cadena de severidad explícita, la usamos primero
    if (severityStr) {
      const severityLower = severityStr.toLowerCase();
      if (severityLower.includes('crítico') || 
          severityLower.includes('grave') || 
          severityLower.includes('peligroso')) {
        return 'high';
      } else if (severityLower.includes('moderado') || 
                severityLower.includes('advertencia') || 
                severityLower.includes('precaución')) {
        return 'medium';
      } else if (severityLower.includes('menor') || 
                severityLower.includes('leve') || 
                severityLower.includes('simple')) {
        return 'low';
      }
    }
    
    // Si no hay severidad explícita o no se reconoció, analizamos el diagnóstico
    const diagnosisLower = diagnosis.toLowerCase();
    
    // Palabras clave de alta severidad
    if (diagnosisLower.includes('peligro') || 
        diagnosisLower.includes('urgente') || 
        diagnosisLower.includes('no conducir') ||
        diagnosisLower.includes('inmediatamente') ||
        diagnosisLower.includes('grave') ||
        diagnosisLower.includes('fallo crítico')) {
      return 'high';
    } 
    
    // Palabras clave de severidad media
    else if (diagnosisLower.includes('precaución') || 
            diagnosisLower.includes('revisar pronto') || 
            diagnosisLower.includes('atención') ||
            diagnosisLower.includes('problema') ||
            diagnosisLower.includes('deterioro') ||
            diagnosisLower.includes('falla')) {
      return 'medium';
    } 
    
    // Palabras clave de baja severidad
    else if (diagnosisLower.includes('buen estado') || 
            diagnosisLower.includes('fácil solución') ||
            diagnosisLower.includes('no es grave') ||
            diagnosisLower.includes('mantenimiento') ||
            diagnosisLower.includes('revision rutinaria')) {
      return 'low';
    } 
    
    // Por defecto, si no encontramos palabras clave
    return 'none';
  };

  const handleSendMessage = async (message: string) => {
    // Add user message to chat
    const userMessage: ChatMessage = {
      id: Date.now().toString(),
      role: 'user',
      content: message
    };
    
    setMessages((prev) => [...prev, userMessage]);
    setIsThinking(true);

    try {
      // Prepare any additional info to send
      const additionalInfo = message;

      // Make API request to get AI diagnosis
      const response = await apiRequest('POST', '/api/diagnostics/analyze', {
        vehicleInfo,
        obdCodes,
        symptoms,
        additionalInfo,
        chatHistory: messages.map(m => ({ role: m.role, content: m.content }))
      });

      const data = await response.json();
      
      // Check if we got a valid response
      if (data.diagnosis) {
        // Determinar severidad basada en la respuesta
        const severity = determineSeverity(data.diagnosis, data.severity);
        
        // Almacenar la severidad como cadena para uso posterior
        if (data.severity) {
          setSeverity(data.severity);
        }
        
        const assistantMessage: ChatMessage = {
          id: (Date.now() + 1).toString(),
          role: 'assistant',
          content: data.diagnosis,
          severity: severity
        };
        
        setMessages((prev) => [...prev, assistantMessage]);
        
        // Update recommended parts if available
        if (data.recommendedParts) {
          setRecommendedParts(data.recommendedParts);
        }
      } else {
        throw new Error('No se recibió un diagnóstico válido');
      }
    } catch (error) {
      console.error('Error al obtener el diagnóstico:', error);
      
      // Add error message
      const errorMessage: ChatMessage = {
        id: (Date.now() + 1).toString(),
        role: 'assistant',
        content: 'Lo siento, ha ocurrido un error al procesar tu solicitud. Por favor, intenta nuevamente.',
        severity: 'high'
      };
      
      setMessages((prev) => [...prev, errorMessage]);
    } finally {
      setIsThinking(false);
    }
  };

  return (
    <div className="min-h-screen flex flex-col bg-zinc-950">
      {/* Header */}
      <header className="border-b border-zinc-800 p-4 flex items-center justify-between bg-black">
        <div className="flex items-center">
          <Button variant="ghost" size="icon" onClick={() => setLocation('/')}
            className="hover:bg-zinc-800 text-zinc-400 hover:text-zinc-200">
            <ChevronLeft className="h-5 w-5" />
          </Button>
          <span className="ml-2 font-mono uppercase tracking-wide text-zinc-300">
            AUTOLOGIC | <span className="text-green-500 font-bold">OBi-2</span>
            <span className="ml-2 text-xs bg-zinc-800 px-1.5 py-0.5 rounded text-green-400">v1.0</span>
          </span>
        </div>
        <div className="flex items-center">
          <div className="w-2 h-2 rounded-full bg-green-500 mr-1.5 animate-pulse"></div>
          <span className="text-xs text-zinc-500 font-mono">SISTEMA ACTIVO</span>
        </div>
      </header>

      {/* Chat UI */}
      <main className="flex-1 flex flex-col overflow-hidden">
        <div className="flex-grow overflow-y-auto p-4">
          <div className="max-w-3xl mx-auto space-y-6">
            {messages.length === 0 && (
              <div className="py-8">
                <div className="mx-auto max-w-lg bg-zinc-900 border border-zinc-800 rounded-lg p-6 font-mono">
                  <div className="flex items-center mb-6">
                    <div className="relative w-12 h-12 bg-zinc-800 rounded-md flex items-center justify-center mr-4">
                      <Terminal className="h-6 w-6 text-green-400" />
                      <div className="absolute top-0 right-0 w-3 h-3 bg-green-500 rounded-full animate-pulse"></div>
                    </div>
                    <div>
                      <h2 className="text-xl font-bold text-green-400">OBi-2 v1.0</h2>
                      <p className="text-zinc-400 text-xs">Asistente de Diagnóstico Automotriz</p>
                    </div>
                  </div>
                  
                  <div className="mb-4 p-3 bg-zinc-800 rounded border border-zinc-700 text-green-300 text-sm">
                    <span className="text-zinc-500">$</span> <span className="text-green-400">./iniciar-diagnostico.sh</span>
                    <p className="mt-2">Sistema inicializado. Listo para recibir consultas.</p>
                  </div>
                  
                  <p className="text-zinc-400 mb-4 text-sm">
                    Describe los problemas de tu vehículo o síntomas que estás experimentando y 
                    te ayudaré a identificar posibles causas y soluciones.
                  </p>
                  
                  <div className="space-y-2 mb-4">
                    <div className="flex items-center gap-2 text-sm">
                      <CheckCircle className="h-4 w-4 text-green-500" />
                      <span className="text-green-300">Diagnóstico: Todo en orden</span>
                    </div>
                    <div className="flex items-center gap-2 text-sm">
                      <AlertTriangle className="h-4 w-4 text-amber-500" />
                      <span className="text-amber-300">Diagnóstico: Atención requerida</span>
                    </div>
                    <div className="flex items-center gap-2 text-sm">
                      <AlertCircle className="h-4 w-4 text-red-500" />
                      <span className="text-red-300">Diagnóstico: Alerta importante</span>
                    </div>
                  </div>
                  
                  <div className="text-xs text-zinc-500 border-t border-zinc-800 pt-2">
                    Powered by Autologic™. Todos los derechos reservados.
                  </div>
                </div>
              </div>
            )}

            {messages.map((message) => (
              <div 
                key={message.id} 
                className={`flex ${message.role === 'user' ? 'justify-end' : 'justify-start'}`}
              >
                {message.role === 'assistant' && (
                  <div className={`
                    w-8 h-8 rounded-md flex items-center justify-center mr-2 flex-shrink-0 bg-zinc-800 border
                    ${message.severity === 'low' ? 'border-green-700 text-green-400' : 
                       message.severity === 'medium' ? 'border-amber-700 text-amber-400' :
                       message.severity === 'high' ? 'border-red-700 text-red-400' :
                       'border-zinc-700 text-blue-400'}
                  `}>
                    {message.severity === 'low' && <CheckCircle className="h-4 w-4" />}
                    {message.severity === 'medium' && <AlertTriangle className="h-4 w-4" />}
                    {message.severity === 'high' && <AlertCircle className="h-4 w-4" />}
                    {(!message.severity || message.severity === 'none') && <Terminal className="h-4 w-4" />}
                  </div>
                )}
                <div 
                  className={`
                    max-w-[80%] rounded-lg px-4 py-3
                    ${message.role === 'user' 
                      ? 'bg-zinc-700 text-zinc-100' 
                      : message.severity === 'low' 
                        ? 'bg-zinc-900 border border-green-800 text-green-300 font-mono' 
                        : message.severity === 'medium'
                          ? 'bg-zinc-900 border border-amber-800 text-amber-300 font-mono'
                          : message.severity === 'high'
                            ? 'bg-zinc-900 border border-red-800 text-red-300 font-mono'
                            : 'bg-zinc-900 border border-zinc-700 text-zinc-300 font-mono'
                    }
                  `}
                >
                  {message.role === 'assistant' && (
                    <div className="flex items-center text-xs font-medium mb-2 border-b pb-1 border-opacity-30 space-x-1">
                      <span className={`
                        ${message.severity === 'low' ? 'text-green-400' : 
                           message.severity === 'medium' ? 'text-amber-400' :
                           message.severity === 'high' ? 'text-red-400' :
                           'text-blue-400'}
                      `}>
                        <span className="text-zinc-400">[</span>
                        OBi-2
                        <span className="text-zinc-400">]</span>
                      </span>
                      <span className="text-zinc-500">$</span>
                      <span className={`
                        ${message.severity === 'low' ? 'text-green-500' : 
                           message.severity === 'medium' ? 'text-amber-500' :
                           message.severity === 'high' ? 'text-red-500' :
                           'text-blue-500'}
                      `}>
                        {message.severity === 'low' && "diagnostico --estado='todo_en_orden'"}
                        {message.severity === 'medium' && "diagnostico --estado='atencion_requerida'"}
                        {message.severity === 'high' && "diagnostico --estado='alerta_importante'"}
                        {(!message.severity || message.severity === 'none') && "diagnostico --analisis"}
                      </span>
                    </div>
                  )}
                  <p className="whitespace-pre-wrap">{message.content}</p>
                </div>
              </div>
            ))}

            {isThinking && (
              <div className="flex justify-start">
                <div className="w-8 h-8 rounded-md bg-zinc-800 border border-zinc-700 flex items-center justify-center mr-2 flex-shrink-0">
                  <Terminal className="h-4 w-4 text-green-400 animate-pulse" />
                </div>
                <div className="max-w-[80%] rounded-lg px-4 py-3 bg-zinc-900 border border-zinc-700 text-green-400 font-mono">
                  <div className="flex items-center text-xs font-medium mb-2 border-b border-zinc-800 pb-1 space-x-1">
                    <span className="text-green-400">
                      <span className="text-zinc-400">[</span>
                      OBi-2
                      <span className="text-zinc-400">]</span>
                    </span>
                    <span className="text-zinc-500">$</span>
                    <span className="text-green-500">ejecutar --proceso='analisis-diagnostico'</span>
                  </div>
                  <div className="flex items-start">
                    <span className="mr-1 opacity-70">$</span> 
                    <div className="flex flex-col">
                      <span className="text-xs opacity-70">Procesando datos...</span>
                      <div className="flex items-center mt-1 space-x-1">
                        <span className="inline-block w-3 h-3 bg-green-500 opacity-90 animate-pulse"></span>
                        <span className="text-xs opacity-70">Analizando información</span>
                      </div>
                      <div className="h-4 mt-1">
                        <span className="inline-block animate-blink">_</span>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            )}

            <div ref={messagesEndRef} />
          </div>
        </div>

        <div className="border-t border-zinc-800 p-4 bg-black">
          <form 
            onSubmit={handleSubmit}
            className="max-w-3xl mx-auto flex items-center space-x-2"
          >
            <div className="flex items-center text-green-500 font-mono text-sm mr-2">
              <span className="opacity-80">{'>'}</span>
            </div>
            <div className="relative flex-1">
              <Input
                value={inputMessage}
                onChange={(e) => setInputMessage(e.target.value)}
                placeholder="Ingrese comando o descripción del problema..."
                className="bg-zinc-900 border-zinc-700 text-zinc-300 font-mono focus-visible:ring-green-500 focus-visible:ring-opacity-50"
                disabled={isThinking}
              />
            </div>
            <Button 
              type="submit" 
              size="icon"
              variant="outline"
              className="border-zinc-700 bg-zinc-800 hover:bg-zinc-700 text-green-500"
              disabled={!inputMessage.trim() || isThinking}
            >
              <Terminal className="h-4 w-4" />
              <span className="sr-only">Ejecutar</span>
            </Button>
          </form>
          <div className="max-w-3xl mx-auto mt-1.5 flex justify-end">
            <div className="text-xs text-zinc-500 font-mono">OBi-2 v1.0 · Diagnóstico en tiempo real</div>
          </div>
        </div>
      </main>

      {/* Recommended parts (shown when available) */}
      {recommendedParts.length > 0 && (
        <div className="border-t border-zinc-800 p-4 bg-black">
          <div className="max-w-3xl mx-auto">
            <div className="flex items-center text-xs font-mono text-green-400 mb-2">
              <span className="text-zinc-500 mr-1.5">[</span>
              <span>PIEZAS RECOMENDADAS</span>
              <span className="text-zinc-500 ml-1.5">]</span>
            </div>
            <div className="bg-zinc-900 border border-zinc-800 rounded-md p-3 font-mono">
              <div className="flex items-start mb-2">
                <span className="text-zinc-500 mr-2 text-sm">$</span>
                <span className="text-green-400 text-sm">listar-refacciones</span>
              </div>
              <div className="pl-4 space-y-1">
                {recommendedParts.map((part, index) => (
                  <div 
                    key={index} 
                    className="text-zinc-300 text-xs flex items-center"
                  >
                    <span className="text-zinc-500 mr-2">-</span>
                    <span className="text-amber-300">{part}</span>
                  </div>
                ))}
              </div>
              <div className="flex justify-end mt-3">
                <Button size="sm" variant="outline" className="bg-zinc-800 border-zinc-700 hover:bg-zinc-700 text-green-400 text-xs font-mono" asChild>
                  <a href="/diagnostics/details/latest">
                    <span className="mr-1.5">{'>'}</span>Ver catálogo completo
                  </a>
                </Button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default DiagnosticsPage;