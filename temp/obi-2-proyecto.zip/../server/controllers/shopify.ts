import { Router } from 'express';
import { buscarProductos, buscarProductosPorRefaccion } from '../services/shopify';

export function registerShopifyRoutes(app: any, apiPrefix: string) {
  const router = Router();

  /**
   * Buscar productos en Shopify
   * POST /api/shopify/buscar
   * Body: { query: string }
   */
  router.post('/buscar', async (req, res) => {
    try {
      // Usar un string vacío si no hay query, para obtener todos los productos disponibles
      const query = req.body.query ?? '';
      
      // Buscar productos, un query vacío retornará todos los productos disponibles
      const productos = await buscarProductos(query);
      
      return res.json({
        success: true,
        productos
      });
    } catch (error: any) {
      console.error('Error al buscar productos en Shopify:', error);
      return res.status(500).json({
        success: false,
        error: 'Error al buscar productos',
        details: error.message
      });
    }
  });

  /**
   * Buscar productos por refacción específica
   * POST /api/shopify/refaccion
   * Body: { refaccion: string, marca?: string, modelo?: string, anio?: number }
   */
  router.post('/refaccion', async (req, res) => {
    try {
      const { refaccion, marca, modelo, anio } = req.body;
      
      if (!refaccion) {
        return res.status(400).json({
          success: false,
          error: 'Es necesario proporcionar el nombre de la refacción'
        });
      }
      
      // Registramos los parámetros de búsqueda para diagnóstico
      console.log(`Buscando refacción: "${refaccion}" para ${marca || 'cualquier marca'} ${modelo || 'cualquier modelo'} ${anio || 'cualquier año'}`);
      
      const productos = await buscarProductosPorRefaccion(refaccion, marca, modelo, anio);
      
      console.log(`Resultados encontrados: ${productos.length} productos`);
      
      return res.json({
        success: true,
        productos
      });
    } catch (error: any) {
      console.error('Error al buscar refacciones en Shopify:', error);
      return res.status(500).json({
        success: false,
        error: 'Error al buscar refacciones',
        details: error.message
      });
    }
  });

  // Registrar las rutas
  app.use(`${apiPrefix}/shopify`, router);
}